<?php
$cfgDB_HOST = "localhost";
$cfgDB_PORT = "3306";
//$cfgDB_USERNAME = "kaugeb5_valen";
//$cfgDB_PASSWORD = "theproject2012";
$cfgDB_NAME = "kaugeb5_valentine2012";

$cfgDB_USERNAME = "root";
$cfgDB_PASSWORD = "";

?>